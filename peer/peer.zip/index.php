<html>

<head>
  <script src="https://unpkg.com/peerjs@1.3.2/dist/peerjs.min.js"></script>
  <script src="jquery.min.js"></script>
</head>

<body>
  <div>
    <input id="cid" name="cid" value="" placeholder="my id" />
    <br>
    <input id="did" name="did" value="" placeholder="dest id" />
    <br>
    <button onclick="start_connection()">Start connection</button>
    <br>
    <textarea id="mes-box" name="mes-box"></textarea>
    <button onclick="send_message()">send message</button>
    <br>
    <div id="res-box"></div>
  </div>
  <script>
    var peer = new Peer();
    peer.on('open', function(id) {
      console.log('My peer ID is: ' + id);
      $('#cid').val(id);
    });

    function start_connection() {
      var conn = peer.connect($('#did').val());
      conn.on('open', function() {
        // Receive messages
        conn.on('data', function(data) {
          console.log('Received', data);
          $('#res-box').append('<div>' + data + '</div>');
        });

        // Send messages

      });
    }

    function send_message() {
      conn.send($('#mes-box').val());
    }
  </script>
</body>

</html>